
package simli;

import douli.DoublyLinkedList;

public class SimplyLinkedList {

  // Inner class representing a node in the linked list
  private class Node {
    int data;
    Node next;

    // Constructor to create a new node with the given data
    Node(int data) {
      this.data = data;
      this.next = null;
    }
  }

  // Head node of the linked list
  private Node head;
  // Number of nodes in the linked list
  private int size;

  // Constructor to create an empty linked list
  public SimplyLinkedList() {
    this.head = null;
    this.size = 0;
  }

  // Returns the number of nodes in the linked list
  public int size() {
    return size;
  }

  // Returns true if the linked list is empty, false otherwise
  public boolean isEmpty() {
    return size == 0;
  }

  // Adds a new node with the given data to the end of the linked list
  public void insert(int data) {
    Node newNode = new Node(data);
    if (head == null) {
      // If the list is empty, the new node becomes the head
      head = newNode;
    } else {
      // Otherwise, traverse the list to find the last node
      Node current = head;
      while (current.next != null) {
        current = current.next;
      }
      // Set the next field of the last node to the new node
      current.next = newNode;
    }
    size++;
  }

  // Removes the first node with the given data from the linked list, if it exists
  public void delete(int data) {
    if (head == null) {
      // If the list is empty, there's nothing to delete
      return;
    }
    if (head.data == data) {
      // If the node to be deleted is the head, update the head to the next node
      head = head.next;
      size--;
      return;
    }
    // Traverse the list to find the node with the given data
    Node current = head;
    while (current.next != null && current.next.data != data) {
      current = current.next;
    }
    // If the node is found, remove it by updating the next field of the previous
    // node
    if (current.next != null) {
      current.next = current.next.next;
      size--;
    }
  }

  // Prints the data of each node in the linked list, in order
  public void printList() {
    Node current = head;
    while (current != null) {
      System.out.print(current.data + " ");
      current = current.next;
    }
    System.out.println();
  }

}
