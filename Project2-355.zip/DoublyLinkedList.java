

package douli;
import simli.SimplyLinkedList;

public class DoublyLinkedList {
    
    // Inner class representing a node in the doubly linked list
    private class Node {
        int data;
        Node prev;
        Node next;

        // Constructor to create a new node with the given data
        Node(int data) {
            this.data = data;
            this.prev = null;
            this.next = null;
        }
    }
    
    // Head and tail nodes of the doubly linked list
    private Node head;
    private Node tail;
    // Number of nodes in the doubly linked list
    private int size;

    // Constructor to create an empty doubly linked list
    public DoublyLinkedList() {
        this.head = null;
        this.tail = null;
        this.size = 0;
    }

    // Returns the number of nodes in the doubly linked list
    public int size() {
        return size;
    }

    // Returns true if the doubly linked list is empty, false otherwise
    public boolean isEmpty() {
        return size == 0;
    }

    // Adds a new node with the given data to the end of the doubly linked list
    public void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            // If the list is empty, the new node becomes both the head and the tail
            head = newNode;
            tail = newNode;
        } else {
            // Otherwise, add the new node after the tail
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
        size++;
    }

    // Removes the first node with the given data from the doubly linked list, if it exists
    public void delete(int data) {
        if (head == null) {
            // If the list is empty, there's nothing to delete
            return;
        }
        if (head.data == data) {
          
            // if the node that is going to deleted is the head, update the head to a new node
            head = head.next;
            if (head != null) {
                head.prev = null;
            } else {
                // if the list becomes empty, update the tail as well
                tail = null;
            }
            size--;
            return;
        }
        // traverse the list to find the node with the given data
        Node current = head;
        while (current != null && current.data != data) {
            current = current.next;
        }
        // if the node is there then, remove it by updating the previuous and next fields of its ne
        if (current != null) {
            current.prev.next = current.next;
            if (current.next != null) {
                current.next.prev = current.prev;
            } else {
                // if the node is the tail, update the tail to the previous node
                tail = current.prev;
            }
            size--;
        }
    }

    // prints the data of each node in the doubly linked list 
    public void printList() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

}
