import douli.DoublyLinkedList;
import simli.SimplyLinkedList;
// allows read input from various sources in Java
import java.util.Scanner;

public class LinkedListTest {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter N elements to insert: ");
        int n = scanner.nextInt();
        
       SimplyLinkedList simpleList = new SimplyLinkedList();
       DoublyLinkedList doubleList = new DoublyLinkedList();
        
        System.out.println("Inserting N elements in the simple linked list: ");
        for (int i = 0; i < n; i++) {
            System.out.print("Enter element #" + (i+1) + ": ");
            int data = scanner.nextInt();
            simpleList.insert(data);
            simpleList.printList();
        }
        
        System.out.println("Inserting elements into doubly linked list:");
        for (int i = 0; i < n; i++) {
            System.out.print("Enter element #" + (i+1) + ": ");
            int data = scanner.nextInt();
            doubleList.insert(data);
            doubleList.printList();
        }
        
        System.out.print("Enter an element to delete: ");
        int toDelete = scanner.nextInt();
        simpleList.delete(toDelete);
        simpleList.printList();
        doubleList.delete(toDelete);
        doubleList.printList();
        
        scanner.close();
    }
    
}
