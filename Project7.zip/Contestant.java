package class1;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class Contestant implements Comparable<Contestant> {
    private String name;
    private int score;
    private ArrayList<Integer> scores;

    /** Constructor: Creates a new Contestant with the given name and score. */
    public Contestant(String name, int score) {
        this.name = name;
        this.score = score;
        this.scores = new ArrayList<>();
        this.scores.add(score);
    }

    /** Adds a new score to the contestant's list of scores and updates the total score. */
    public void addScore(int newScore) {
        this.scores.add(newScore);
        this.score += newScore;
    }

    /** Returns the name of the contestant. */
    public String getName() {
        return name;
    }

    /** Returns the current score of the contestant. */
    public int getScore() {
        return score;
    }

    /** Returns an array of all the scores for the contestant. */
    public int[] getScores() {
        int[] scoresArray = new int[scores.size()];
        for (int i = 0; i < scores.size(); i++) {
            scoresArray[i] = scores.get(i);
        }
        return scoresArray;
    }

    /** Returns the total score for the contestant. */
    public int getTotalScore() {
        return score;
    }

    /**
     * Returns an array of the top m scores for the contestant, sorted in descending order. If m is
     * greater than the total number of scores, all scores are returned.
     */
    public int[] getTopMScores(int m) {
        Integer[] sortedScores = scores.toArray(new Integer[0]);
        Arrays.sort(sortedScores, Collections.reverseOrder());
        int[] topMScores = new int[Math.min(m, sortedScores.length)];
        for (int i = 0; i < topMScores.length; i++) {
            topMScores[i] = sortedScores[i];
        }
        return topMScores;
    }

    /**
     * Required for implementing Comparable. Compares contestants first by their scores and secondly
     * by their names (alphabetically). The names only need to be compared if the scores are the same.
     */
    @Override
    public int compareTo(Contestant o) {
        int scoreCompare = Integer.compare(o.getScore(), this.score);
        if (scoreCompare != 0) {
            return scoreCompare;
        }
        return this.name.compareTo(o.getName());
    }

    /** Checks whether two contestants have the same name. */
    @Override
    public boolean equals(Object obj) {
        if (obj == null || !(obj instanceof Contestant)) {
            return false;
        }
        Contestant other = (Contestant) obj;
        return this.name.equals(other.getName());
    }

    /** Returns a string representation of the contestant in the format "<name>: <score>". */
    @Override
    public String toString() {
        return name + ": " + score;
    }
}

