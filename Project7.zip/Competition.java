package mainst;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Arrays;
import java.util.List;
import class1.Contestant;

public class Competition {
    private int M;  // instance variable to store the value of M
    private ArrayList<Contestant> contestants;  // instance variable to store the list of contestants

    public Competition(int M) {
        this.M = M;
        contestants = new ArrayList<Contestant>();
    }

    // other methods in the Competition class
  public void processScore(String name, int score) {
    // check if the contestant already exists in the list
    for (Contestant c : contestants) {
        if (c.getName().equals(name)) {
            // if the contestant exists, add the score to their list of scores
            c.addScore(score);
            return;
        }
    }

    // if the contestant does not exist, create a new Contestant object and add it to the list
    Contestant newContestant = new Contestant(name, score);
    contestants.add(newContestant);
}

public String totalScore(String name) {
    // find the contestant with the given name
    Contestant c = null;
    for (Contestant contestant : contestants) {
        if (contestant.getName().equals(name)) {
            c = contestant;
            break;
        }
    }

    // if the contestant is not found, return an error message
    if (c == null) {
        return "Contestant not found!";
    }

    // calculate the total score as the sum of the top M scores
    int[] scores = c.getScores();
    if (scores.length == 0) {
        return "0";  // if there are no scores, the total score is 0
    } else if (scores.length <= M) {
        return Integer.toString(Arrays.stream(scores).sum());
    } else {
        Arrays.sort(scores);  // sort the scores in ascending order
        int topMSum = Arrays.stream(Arrays.copyOfRange(scores, scores.length - M, scores.length)).sum();
        return Integer.toString(topMSum);
    }
}

public String scores(String name) {
    // find the contestant with the given name
    Contestant c = null;
    for (Contestant contestant : contestants) {
        if (contestant.getName().equals(name)) {
            c = contestant;
            break;
        }
    }

    // if the contestant is not found, return an error message
    if (c == null) {
        return "Contestant not found!";
    }

    // get the top M scores for the contestant
    int[] topMScores = c.getTopMScores(M);

    // if the contestant has no scores, return an empty string
    if (topMScores.length == 0) {
        return "";
    }

    // sort the top M scores in descending order
    Arrays.sort(topMScores);
    int[] sortedScores = new int[topMScores.length];
    for (int i = 0; i < topMScores.length; i++) {
        sortedScores[i] = topMScores[topMScores.length - i - 1];
    }

    // return the sorted top M scores as a string
    return Arrays.toString(sortedScores);
}

public String top(int m) {
    // sort the contestants based on their total score
    Collections.sort(contestants);

    // iterate over the sorted list of contestants and add them to the top list until we have at least m scores
    List<String> topList = new ArrayList<>();
    int lastScore = -1;
    for (Contestant c : contestants) {
        int totalScore = c.getTotalScore();
        if (totalScore != lastScore) {
            topList.add(c.getName());
            lastScore = totalScore;
        } else {
            topList.add(c.getName());
        }
        if (topList.size() >= m && totalScore != lastScore) {
            break;
        }
    }

    // return the top list as a String
    return String.join(", ", topList);
}

  public String bottom(int m) {
    // sort the contestants based on their total score
    Collections.sort(contestants);

    // iterate over the sorted list of contestants in reverse order and add them to the bottom list until we have at least m scores
    List<String> bottomList = new ArrayList<>();
    int lastScore = Integer.MAX_VALUE;
    for (int i = contestants.size() - 1; i >= 0; i--) {
        Contestant c = contestants.get(i);
        int totalScore = c.getTotalScore();
        if (totalScore != lastScore) {
            bottomList.add(c.getName());
            lastScore = totalScore;
        } else {
            bottomList.add(c.getName());
        }
        if (bottomList.size() >= m && totalScore != lastScore) {
            break;
        }
    }

    // reverse the order of the bottom list and return it as a String
    Collections.reverse(bottomList);
    return String.join(", ", bottomList);
}

  public String rank(String name) {
    // sort the contestants based on their total score
    Collections.sort(contestants);

    // iterate over the sorted list of contestants in reverse order to determine the ranks
    int lastScore = Integer.MAX_VALUE;
    int rank = 1;
    for (int i = contestants.size() - 1; i >= 0; i--) {
        Contestant c = contestants.get(i);
        int totalScore = c.getTotalScore();
        if (totalScore != lastScore) {
            rank = contestants.size() - i;
            lastScore = totalScore;
        }
        if (c.getName().equals(name)) {
            return Integer.toString(rank);
        }
    }

    // if the given name is not found in the list of contestants, return "0" to indicate an error
    return "0";
}

public String ranked(int rank) {
    // sort the contestants based on their total score
    Collections.sort(contestants);

    // iterate over the sorted list of contestants to find all contestants with the given rank
    List<Contestant> rankedContestants = new ArrayList<>();
    for (int i = contestants.size() - 1; i >= 0; i--) {
        Contestant c = contestants.get(i);
        if (contestants.size() - i == rank) {
            rankedContestants.add(c);
        } else if (contestants.size() - i > rank) {
            break;
        }
    }

    // sort the ranked contestants based on their names
    Collections.sort(rankedContestants, Comparator.comparing(Contestant::getName));

    // return a String representation of the ranked contestants
    StringBuilder sb = new StringBuilder();
    for (Contestant c : rankedContestants) {
        sb.append(c.toString());
        sb.append("\n");
    }
    return sb.toString().trim();
}

  

  
}
