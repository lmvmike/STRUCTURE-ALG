import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner; 
import java.util.Collections;
import mainst.Competition;
import class1.Contestant;

public class CompetitionTest {
    private int M;
    private ArrayList<Contestant> contestants;

    public CompetitionTest(int M, String fileName) throws FileNotFoundException {
        this.M = M;
        contestants = new ArrayList<Contestant>();

        // read the values from the file
        File file = new File(fileName);
        Scanner scanner = new Scanner(file);
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            String[] parts = line.split(" ");
            if (parts.length != 2) {
                System.out.println("Invalid input format:(Proper fomat: Maria 5) " + line);
                continue;
            }
            String name = parts[0];
            int score = Integer.parseInt(parts[1]);
            processScore(name, score);
        }
        scanner.close();
    }

    public void processScore(String name, int score) {
        // Find the contestant with the given name, or create a new contestant if none exists
        Contestant contestant = null;
        for (Contestant c : contestants) {
            if (c.getName().equals(name)) {
                contestant = c;
                break;
            }
        }
        if (contestant == null) {
            contestant = new Contestant(name, score);
            contestants.add(contestant);
        } else {
            contestant.addScore(score);
        }
    }

    public static void main(String[] args) {
        try {
            CompetitionTest competition = new CompetitionTest(3, "names.txt");
            for (Contestant c : competition.getTopMContestants()) {
                System.out.println(c);
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + e.getMessage());
        }
    }

    public Contestant[] getTopMContestants() {
        // Sort the contestants by score, then by name
        Collections.sort(contestants);

        // Get the top M contestants
        int numContestants = Math.min(M, contestants.size());
        Contestant[] topMContestants = new Contestant[numContestants];
        for (int i = 0; i < numContestants; i++) {
            topMContestants[i] = contestants.get(i);
        }
        return topMContestants;
    }
}