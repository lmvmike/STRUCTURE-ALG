package class1;
import mainfile.Puzzle;
import class2.WordSearch;

public class Grid {
    private char[][] grid;
    private int numRows;
    private int numCols;

    public Grid(char[][] grid) {
        this.grid = grid;
        this.numRows = grid.length;
        this.numCols = grid[0].length;
    }

    public char getChar(int row, int col) {
        return grid[row][col];
    }

    public int getNumRows() {
        return numRows;
    }

    public int getNumCols() {
        return numCols;
    }

    public int getRows() {
        return this.grid.length;
    }

    public int getCols() {
        return this.grid[0].length;
    }
}
