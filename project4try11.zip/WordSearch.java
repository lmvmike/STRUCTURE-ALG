package class2;
import mainfile.Puzzle;
import class1.Grid;
// this file is equal to my PuzzleTest.java file for some reason i had an issue calling this file as puzzle testing for that reason, i had to declared like that.
public class WordSearch {
    public static void main(String[] args) {
        Grid grid = new Grid(new char[][]{
            {'A','N','O','D','E','F','G','H','I','J'},
            {'R','O','N','N','O','P','Q','W','E','R'},
            {'I','Z','A','E','R','P','A','S','D','F'},
            {'G','H','J','V','S','L','G','H','J','K'},
            {'A','S','W','S','R','F','F','G','H','J'},
            {'B','A','M','N','I','V','C','X','Z','A'},
            {'S','W','Y','U','R','E','V','T','B','Y'},
            {'N','D','C','I','S','R','P','O','G','H'},
            {'I','L','A','T','Y','S','C','V','R','F'},
            {'W','S','T','A','S','D','F','G','H','E'}
        });
        Puzzle puzzle = new Puzzle(grid);
        for (String word : puzzle.getWords()) {
            System.out.println(word);
        }
    }
}
