package mainfile;
import class1.Grid;
import class2.WordSearch;
import java.util.ArrayList;
import java.util.Arrays;
//WordSearch = PuzzleTesting
public class Puzzle {

    private Grid grid;

    public Puzzle(Grid grid) {
        this.grid = grid;
    }

    public String find(String word, int r, int c) {
        ArrayList<String> path = new ArrayList<String>();
        boolean[][] visited = new boolean[grid.getRows()][grid.getCols()];
        if (findWord(word, r, c, path, visited)) {
            StringBuilder result = new StringBuilder();
            for (String coord : path) {
                result.append(coord);
            }
            return result.toString();
        }
        return null;
    }

    private boolean findWord(String word, int r, int c, ArrayList<String> path, boolean[][] visited) {
        if (word.length() == 0) {
            return true;
        }
        if (r < 0 || r >= grid.getRows() || c < 0 || c >= grid.getCols() || visited[r][c]) {
            return false;
        }
        char ch = word.charAt(0);
        if (grid.getChar(r, c) != ch) {
            return false;
        }
        visited[r][c] = true;
        path.add(String.format("(%d,%d)", r, c));
        int[] dR = {-1, 0, 1, 0};
        int[] dC = {0, 1, 0, -1};
        for (int i = 0; i < 4; i++) {
            int newRow = r + dR[i];
            int newCol = c + dC[i];
            if (findWord(word.substring(1), newRow, newCol, path, visited)) {
                return true;
            }
        }
        visited[r][c] = false;
        path.remove(path.size() - 1);
        return false;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int r = 0; r < grid.getRows(); r++) {
            for (int c = 0; c < grid.getCols(); c++) {
                sb.append(grid.getChar(r, c));
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    public ArrayList<String> getWords() {
        ArrayList<String> words = new ArrayList<String>(Arrays.asList(
                "ARIZONA", "UNIVERSITY", "WILDCATS"));
        ArrayList<String> foundWords = new ArrayList<String>();
        for (String word : words) {
            for (int r = 0; r < grid.getRows(); r++) {
                for (int c = 0; c < grid.getCols(); c++) {
                    if (word.charAt(0) == grid.getChar(r, c)) {
                        String path = find(word, r, c);
                        if (path != null) {
                            foundWords.add(word + ": " + path);
                        }
                    }
                }
            }
        }
        return foundWords;
    }
  
}


