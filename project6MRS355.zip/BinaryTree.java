public class BinaryTree {

    public static void main(String[] args) {
        // Create a new instance of the Tree class
        Tree<Integer, String> tree = new Tree<>();

        // Add nodes to the tree with keys and values
        tree.put(10, "ten");
        tree.put(5, "five");
        tree.put(15, "fifteen");
        tree.put(3, "three");
        tree.put(7, "seven");
        tree.put(13, "thirteen");
        tree.put(17, "seventeen");

        // Print out the size and height of the tree
        System.out.println("Size of tree: " + tree.size());
        System.out.println("Height of tree: " + tree.height());

        // Check if certain keys exist in the tree, and print their values and subtree sizes
        System.out.println("\nKeys in tree:");
        for (Integer key : new Integer[]{3, 5, 7, 10, 13, 15, 17}) {
            System.out.println("Key " + key + " is in tree: " + tree.contains(key));
            System.out.println("Value for key " + key + ": " + tree.get(key));
            System.out.println("Size of subtree rooted at key " + key + ": " + tree.size(key));
            System.out.println("Height of subtree rooted at key " + key + ": " + tree.height(key));
            System.out.println();
        }

        // Remove a key from the tree and print out the updated size and height
        System.out.println("Removing key 13");
        tree.remove(13);
        System.out.println("Size of tree: " + tree.size());
        System.out.println("Height of tree: " + tree.height());
        System.out.println("Key 13 is in tree: " + tree.contains(13));
        System.out.println();
    }
}
