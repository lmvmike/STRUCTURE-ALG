public class Tree<K extends Comparable<K>, V> {

    private class Node { //root of tree  inner class for a node in the tree
        K key; // key of the node
        V value; // value associated with the key
        Node left, right;
        int size, height;

        Node(K key, V value) {
            this.key = key;
            this.value = value;
            this.size = 1;
            this.height = 1;
        }
    }

    private Node root;
// constructor for creating a new node
    public void put(K key, V val) {
        root = put(root, key, val);
    }

    private Node put(Node node, K key, V val) {
        if (node == null) return new Node(key, val);
        int cmp = key.compareTo(node.key);
        if (cmp < 0) node.left = put(node.left, key, val);
        else if (cmp > 0) node.right = put(node.right, key, val);
        else node.value = val;
        node.size = 1 + size(node.left) + size(node.right);
        node.height = 1 + Math.max(height(node.left), height(node.right));
        return node;
    }

    public V get(K key) {
        Node node = get(root, key);
        return node == null ? null : node.value;
    }

    private Node get(Node node, K key) {
        if (node == null) return null;
        int cmp = key.compareTo(node.key);
        if (cmp < 0) return get(node.left, key);
        else if (cmp > 0) return get(node.right, key);
        else return node;
    }

    public boolean isEmpty() {
        return size() == 0;
    }

    public int size() {
        return size(root);
    }

    private int size(Node node) {
        return node == null ? 0 : node.size;
    }

    public int height() {
        return height(root);
    }

    private int height(Node node) {
        return node == null ? 0 : node.height;
    }

    public int height(K key) {
        Node node = get(root, key);
        return node == null ? -1 : node.height;
    }

    public boolean contains(K key) {
        return get(key) != null;
    }

    public int size(K key) {
        Node node = get(root, key);
        return node == null ? -1 : node.size;
    }
  public void remove(K key) {
    root = remove(root, key);
}

private Node remove(Node node, K key) {
    if (node == null) return null;
    int cmp = key.compareTo(node.key);
    if (cmp < 0) node.left = remove(node.left, key);
    else if (cmp > 0) node.right = remove(node.right, key);
    else {
        if (node.left == null) return node.right;
        if (node.right == null) return node.left;
        Node t = node;
        node = min(t.right);
        node.right = deleteMin(t.right);
        node.left = t.left;
    }
    node.size = 1 + size(node.left) + size(node.right);
    node.height = 1 + Math.max(height(node.left), height(node.right));
    return node;
}

private Node deleteMin(Node node) {
    if (node.left == null) return node.right;
    node.left = deleteMin(node.left);
    node.size = 1 + size(node.left) + size(node.right);
    node.height = 1 + Math.max(height(node.left), height(node.right));
    return node;
}

private Node min(Node node) {
    if (node.left == null) return node;
    else return min(node.left);
}

}
