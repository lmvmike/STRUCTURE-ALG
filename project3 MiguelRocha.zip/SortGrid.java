package class3;//class belongs to the "class3" package

public class SortGrid {
    public static void sort(int[][] grid) {
      //defines the sort method that takes a two-dimensional integer array (as an example: grid) as input.
        int numRows = grid.length;// hold the number of rows in the grid
        int numCols = grid[0].length;// hold the number of columns in the grid
      //loops iterate over each element in the grid, comparing each element to every other elemen
        for (int row = 0; row < numRows; row++) {
            for (int col = 0; col < numCols; col++) {
                for (int i = row; i < numRows; i++) {
                    for (int j = 0; j < numCols; j++) {
                        if (i == row && j <= col) {
                            continue;
                        }
                        if (grid[i][j] < grid[row][col]) {
                            swap(grid, row, col, i, j);
                        }
                    }
                }
            }
        }
    }

    private static void swap(int[][] grid, int row1, int col1, int row2, int col2) {
      //method exchanges the elements at the two specified positions
        int temp = grid[row1][col1];
        grid[row1][col1] = grid[row2][col2];
        grid[row2][col2] = temp;
    }
}


