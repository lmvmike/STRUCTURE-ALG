package class2;//declares the package name

import java.util.Arrays;//imports the java.util.Arrays package, which provides various utility methods for working with arrays

public class MergeSort {//declares the MergeSort class 
    public static void sort(int[] arr) {//declares a public static method named sort which takes an integer array arr as input
      
        if (arr.length > 1) { //checks if the length of arr is greater than 1
            int mid = arr.length / 2; //divide the input array arr into two halves, left and right, and copies the elements of each half into separate arrays
            int[] left = Arrays.copyOfRange(arr, 0, mid);
            int[] right = Arrays.copyOfRange(arr, mid, arr.length);
            sort(left);
            sort(right);
            merge(left, right, arr);
        }
    }

    private static void merge(int[] left, int[] right, int[] arr) {
      // declares a private static method named merge which takes two sorted integer arrays left and right and an integer array array as input not 100% if it is going to work propertly
        int i = 0, j = 0, k = 0;//nitialize variables i, j, and k to 0. i and j will be used to iterate through the left and right arrays
        while (i < left.length && j < right.length) {
            if (left[i] <= right[j]) {
                arr[k++] = left[i++];
            } else {
                arr[k++] = right[j++];
            }
        }
      //two while loops add any remaining elements from the left or right arrays to the end of the arr array
        while (i < left.length) {
            arr[k++] = left[i++];
        }
        while (j < right.length) {
            arr[k++] = right[j++];
        }
    }
}
