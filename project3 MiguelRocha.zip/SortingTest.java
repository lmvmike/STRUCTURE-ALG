import class1.Shellsort;
import class2.MergeSort;
import class3.SortGrid;

import java.util.Arrays;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

/*
public class SortingTest {
    public static void main(String[] args) throws IOException {
        int[] array1 = readArrayFromFile("array1.txt");
        int[] array2 = readArrayFromFile("array2.txt");
        int[] array3 = readArrayFromFile("array3.txt");
        int[] array4 = readArrayFromFile("array4.txt");
        int[] array5 = readArrayFromFile("array5.txt");

        int[][] arrays = {array1, array2, array3, array4, array5};

        for (int i = 0; i < arrays.length; i++) {
            int[] arr = arrays[i];
            System.out.println("Before sorting: " + Arrays.toString(arr));
            Shellsort.sort(arr);
            System.out.println("After sorting: " + Arrays.toString(arr));
        }
    }

    private static int[] readArrayFromFile(String filename) throws IOException {
        String content = new String(Files.readAllBytes(Paths.get(filename)));
        String[] tokens = content.split("\\s+");
        int[] arr = new int[tokens.length];
        for (int i = 0; i < tokens.length; i++) {
            arr[i] = Integer.parseInt(tokens[i]);
        }
        return arr;
    }
}

*/


public class SortingTest {
    
    public static void main(String[] args) throws IOException {
        int[][] grid1 = readGridFromFile("array1.txt");
        int[][] grid2 = readGridFromFile("array2.txt");
        int[][] grid3 = readGridFromFile("array3.txt");
        int[][] grid4 = readGridFromFile("array4.txt");
        int[][] grid5 = readGridFromFile("array5.txt");

        int[][][] grids = {grid1, grid2, grid3, grid4, grid5};

        for (int i = 0; i < grids.length; i++) {
            int[][] grid = grids[i];
            System.out.println("Grid " + (i+1) + "before sorting: ");
            printGrid(grid);
            SortGrid.sort(grid);
            System.out.println("Grid " + (i+1) + "after sorting: ");
            printGrid(grid);
            System.out.println();
        }
    }
    
    private static int[][] readGridFromFile(String filename) throws IOException {
        List<String> lines = Files.readAllLines(Paths.get(filename));
        int numRows = lines.size();
        int[][] grid = new int[numRows][];
        for (int row = 0; row < numRows; row++) {
            String[] values = lines.get(row).split(" ");
            int numCols = values.length;
            grid[row] = new int[numCols];
            for (int col = 0; col < numCols; col++) {
                grid[row][col] = Integer.parseInt(values[col]);
            }
        }
        return grid;
    }

    private static void printGrid(int[][] grid) {
        for (int row = 0; row < grid.length; row++) {
            for (int col = 0; col < grid[row].length; col++) {
                System.out.print(grid[row][col] + " ");
            }
            System.out.println();
        }
    }
}






